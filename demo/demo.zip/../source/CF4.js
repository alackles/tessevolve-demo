$.getScript("./landscape.js", function()
    {;
        fname = "../data/coords_CF4.csv";
        load_landscape(fname);
    }

)


