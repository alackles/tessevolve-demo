$.getScript("./landscape.js", function()
    {;
        fname = "../data/coords_CF3.csv";
        load_landscape(fname);
    }

)


