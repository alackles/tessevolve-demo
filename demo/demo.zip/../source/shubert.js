$.getScript("./landscape.js", function()
    {;
        fname = "../data/coords_shubert.csv";
        load_landscape(fname);
    }

)


