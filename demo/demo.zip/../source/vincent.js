$.getScript("./landscape.js", function()
    {;
        fname = "../data/coords_vincent.csv";
        load_landscape(fname);
    }

)


